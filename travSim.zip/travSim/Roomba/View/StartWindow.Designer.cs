﻿namespace Roomba.View
{
    partial class StartWindow
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnTurnOn = new System.Windows.Forms.Button();
            this.btnCleanTiles = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnTurnOn
            // 
            this.btnTurnOn.Location = new System.Drawing.Point(38, 133);
            this.btnTurnOn.Name = "btnTurnOn";
            this.btnTurnOn.Size = new System.Drawing.Size(120, 65);
            this.btnTurnOn.TabIndex = 0;
            this.btnTurnOn.Text = "Switch Roomba ON";
            this.btnTurnOn.UseVisualStyleBackColor = true;
            this.btnTurnOn.Click += new System.EventHandler(this.btnTurnOn_Click);
            // 
            // btnCleanTiles
            // 
            this.btnCleanTiles.Enabled = false;
            this.btnCleanTiles.Location = new System.Drawing.Point(278, 133);
            this.btnCleanTiles.Name = "btnCleanTiles";
            this.btnCleanTiles.Size = new System.Drawing.Size(120, 65);
            this.btnCleanTiles.TabIndex = 1;
            this.btnCleanTiles.Text = "Clean Dirty Tiles";
            this.btnCleanTiles.UseVisualStyleBackColor = true;
            this.btnCleanTiles.Click += new System.EventHandler(this.btnCleanTiles_Click);
            // 
            // StartWindow
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(441, 233);
            this.Controls.Add(this.btnCleanTiles);
            this.Controls.Add(this.btnTurnOn);
            this.Name = "StartWindow";
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Roomba Tile Cleaner";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnTurnOn;
        private System.Windows.Forms.Button btnCleanTiles;
    }
}