﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Forms;
using System.Windows.Media;
using System.Windows.Shapes;
using Brushes = System.Drawing.Brushes;
using Color = System.Windows.Media.Color;
using Pen = System.Drawing.Pen;
using Rectangle = System.Windows.Shapes.Rectangle;

namespace Roomba.View
{
    public partial class StartWindow : Form
    {
        public StartWindow()
        {
            InitializeComponent();
        }
        //StartWindow start = new StartWindow();
        int[] dirtyTiles = new int[18];
        int[] cleanTiles = new int[64];
        private void btnTurnOn_Click(object sender, EventArgs e)
        {
            //When Roomba is turned on make 18 Random tiles dirty
            //Save them in an array and search for best path to clean
            Random tiles = new Random();
            int pos;
            for (int i = 0; i < dirtyTiles.Length; i++)
            {
                pos = tiles.Next(1,64);

                while (IsDirty(pos, dirtyTiles))
                {
                    pos = tiles.Next(1, 64);
                }
                dirtyTiles[i] = pos;
            }
            btnCleanTiles.Enabled = true;
        }

        private static bool IsDirty(int pos, int[] dirtyTiles) 
        {
            foreach (var item in dirtyTiles)
            {
                if (item == pos)
                {
                    return true;
                }
            }
            return false;
        }


        private void btnCleanTiles_Click(object sender, EventArgs e)
        {
            this.Close();
            TileFloor tileFloor = new TileFloor();
            SolidColorBrush brush = new SolidColorBrush();
            brush.Color = Color.FromRgb(200, 160, 10);
            string dirtyTiler;
            Array.Sort(dirtyTiles);
            Rectangle x;
            for (int i = 0; i < dirtyTiles.Length; i++)
            {
                dirtyTiler = "tile" + dirtyTiles[i];
                x = (Rectangle) tileFloor.FindName(dirtyTiler);
                x.Fill = brush;
            }
            MoveRight();
            Window tileCleaner = new Window
            {
                Title = "Roomba",
                Content = tileFloor
            };
            tileCleaner.ShowDialog();
        }
        
        Rectangle roomba;
        Graphics graphics;
        Timer timer = new Timer();
        int x_axis = 0, y_axis = 0;
        private void MoveRight() 
        {
            while (x_axis < 408) 
            {
                roomba = new Rectangle
                {
                    RadiusX = x_axis
                };
                graphics = this.CreateGraphics();

                timer.Interval = 1000;
                timer.Tick += new EventHandler(timer_Tick);
                timer.Start();
                x_axis += 56;
            }
        }

        void timer_Tick(object sender, EventArgs e) 
        {
            roomba = new Rectangle();
            //graphics.DrawEllipse(new Pen(Brushes.Black), roomba);
        }
        private void MoveLeft()
        { 
        }
        private void MoveUp() 
        { 
        }
        private void MoveDown()
        { }

    }
}
